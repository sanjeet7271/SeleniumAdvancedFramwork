package com.nagp.framework.constants;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

/**
 * 
 * @author sanjeet.pandit
 *
 */
public class ReportConstant {
	public static ExtentTest PARENTTEST;
	public static ExtentTest STEP ;
	public static ExtentReports EXTENT;
	public static String HTML_REPORT;
	public static String EXCEL_REPORT;
}
