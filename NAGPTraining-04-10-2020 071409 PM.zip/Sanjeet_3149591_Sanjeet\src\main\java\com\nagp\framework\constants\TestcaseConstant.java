package com.nagp.framework.constants;

/**
 * 
 * @author sanjeet.pandit
 *
 */
public class TestcaseConstant {
	public static String TESTCASE_STARTTIME = "";
	public static String TESTCASE_ENDTIME = "";
	public static Integer STEP_COUNTER = 0;
}
