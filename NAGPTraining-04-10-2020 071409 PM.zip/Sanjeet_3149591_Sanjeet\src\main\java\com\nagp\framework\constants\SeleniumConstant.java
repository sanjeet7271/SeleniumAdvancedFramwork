package com.nagp.framework.constants;

/**
 * 
 * @author sanjeet.pandit
 *
 */
public class SeleniumConstant {
	public static int DEFAULTTIMEOUT = 0;
	public static int PAGELOADTIMEOUT = 0;
	public static String SCREEN_SHOT = "";
	public static String BROWSER_PID = "";
}
