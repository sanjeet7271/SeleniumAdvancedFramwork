package com.nagp.testcase;

import java.io.IOException;

import org.testng.annotations.Test;

import com.nagp.framework.constants.FrameworkConstant;
import com.nagp.pages.Pages;
import com.nagp.utility.selenium.SeleniumFramework;

/**
 * 
 * @author sanjeetpandit
 *
 */
public class TC_004_SearchAndPlacedOrder implements SeleniumFramework, Pages {

	@Test(priority = 1, description = "Navigation to Home Page")
	public void initialization() throws IOException {
		String url = FrameworkConstant.GLOBALCONFIG.get("URL");
		driver.get(url);
		logger.info(url);
	}

	@Test(priority = 2, description = "filter the price range")
	public void filter_PriceBar_And_Place_An_Order() {

		placeOder.filterPriceBar();
		placeOder.placeAnOrder();

	}

}
