package com.nagp.pages;

/**
 * 
 * @author sanjeetpandit
 *
 */
public interface Pages {

	SearchAndAddToCart homePage = new SearchAndAddToCart();
	RegisterPage register = new RegisterPage();
	LoginPage login = new LoginPage();
	SearchAndPlacedOrder placeOder = new SearchAndPlacedOrder();
	ContactPage contact = new ContactPage();

}
